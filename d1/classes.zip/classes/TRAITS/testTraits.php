<?php






function zzz( $var = null)
{
  echo 'zzz';
}





trait testTrait{
  public function testfun(){
    echo 'fevrvrvf';
  }
}



trait Basic{
  public function initial_imports(){
    return "
import numpy as np;
import re;import collections;import contractions;
import seaborn as sns;import matplotlib.pyplot as plt;
plt.style.use('dark_background')";
  }
}












 ?>
