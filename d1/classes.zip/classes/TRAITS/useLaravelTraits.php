<?php




class useLaravelTraits 
{
    function __construct(){
        $this->obj = new laravelTraits();
    }
    function action(){
        pr( $this->obj->all_avail());
    }
    
}



