<?php




class System 
{
    public function __construct()
    {
        include 'TRAITS/testTraits.php';
        include 'core/addOns/object_oriented_addons.php';
    }
}












?>