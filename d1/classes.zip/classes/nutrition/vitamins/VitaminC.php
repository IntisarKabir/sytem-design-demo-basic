<?php





interface VitaminC{
    public function how();
}















?>