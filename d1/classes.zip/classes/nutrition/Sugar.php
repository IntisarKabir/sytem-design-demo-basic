<?php




interface Sugar{
    
}







?>