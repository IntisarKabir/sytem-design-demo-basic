<?php



class Orange  implements VitaminC
{
     public function how( $var = null)
    {
        return "orange has a lot of vit-c"; 
    }
}















?>