<?php






function chk_o_im_i($o, $interf, $yes=0)
{
    
if ($o instanceof $interf) {
    if ($yes) {
       return "yes";
    }else{
        return 1;
    }
    
}else{
    return 0;
}

}













?>