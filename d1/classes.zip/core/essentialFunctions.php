<?php

function pp($v){
    echo '<pre>';
    print_r( $v);
    echo '</pre>';
  }
  
function br($n=1){
  for ($i=0; $i < $n; $i++) { 
    echo '<br/>';
  } 
}

function pr($z){
  print_r($z);
} 

function pr_(){
  echo '<pre>';
}
function pr__(){
  echo '</pre>';
}
   
function print_c($cn, $m=''){
  $c = new $cn;
  if($m == '') {
    $cm = get_class_methods($cn);
    print_r ( $cm );
    echo '<br/>';
    $V = (get_class_vars($cn ));
    print_r ( $V );
    
  }else{
    print_r ( $c->$m()  );
  }
}


  
function print_o($cn, $m=''){
  if($m == '') {
    $cm = get_class_methods(get_class($cn));
    print_r ( $cm );
    echo '<br/>';
    $V = (get_object_vars($cn ));
    print_r ( $V );
  }else{
    print_r ( $cn->$m()  );
  }
}


function TO($object){ //Test Object
  if(!is_object($object)){
      throw new Exception("This is not a Object"); 
      return;
  }
  if(class_exists(get_class($object), true)) echo "<pre>CLASS NAME = ".get_class($object);
  $reflection = new ReflectionClass(get_class($object));
  echo "<br />";
  echo $reflection->getDocComment();

  echo "<br />";

  $metody = $reflection->getMethods();
  foreach($metody as $key => $value){
      echo "<br />". $value;
  }

  echo "<br />";

  $vars = $reflection->getProperties();
  foreach($vars as $key => $value){
      echo "<br />". $value;
  }
  echo "</pre>";
}









?>